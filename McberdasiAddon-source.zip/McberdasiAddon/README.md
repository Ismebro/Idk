# Mcberdasi Addon

One combined Meteor Client addon project. New modules should be added to this same project and registered in `McberdasiAddon.java`; do not create a separate addon JAR per feature.

## Included module

- **Fake Lag**: delays outgoing player movement packets, with a configurable delay and queue cap.
- Disabling the module flushes queued packets so they are not intentionally stranded.

## Target

- Minecraft Java 1.21.11
- Java 21
- Fabric Loader
- Meteor Client 1.21.11 build

## Build

Run on a Java 21 environment with network access:

```sh
./gradlew build
```

The output JAR should be in `build/libs/`.

This initial scaffold has **not been compiled or tested in-game** in this environment. The Meteor Maven artifact/version and Loom plugin version may need to be adjusted to the exact Meteor 1.21.11 build being used. Test on a private server first; delayed movement can be corrected or flagged by server anti-cheat.
