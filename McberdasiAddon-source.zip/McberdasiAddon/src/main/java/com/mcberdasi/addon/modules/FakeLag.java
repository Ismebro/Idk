package com.mcberdasi.addon.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import static com.mcberdasi.addon.McberdasiAddon.CATEGORY;

/**
 * Delays outgoing player-movement packets. Intended for private/testing servers.
 * Server-side anti-cheat may detect or correct the resulting movement.
 */
public class FakeLag extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("How long to hold movement packets before sending them (milliseconds).")
        .defaultValue(350)
        .min(50)
        .max(2000)
        .sliderMin(50)
        .sliderMax(1000)
        .build()
    );

    private final Setting<Boolean> movementOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("movement-only")
        .description("Only delay player movement packets; chat and interactions are not queued.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> maxQueued = sgGeneral.add(new IntSetting.Builder()
        .name("max-queued")
        .description("Safety limit for queued movement packets.")
        .defaultValue(120)
        .min(10)
        .max(500)
        .sliderMin(10)
        .sliderMax(250)
        .build()
    );

    private final Queue<QueuedPacket> queue = new ConcurrentLinkedQueue<>();

    public FakeLag() {
        super(CATEGORY, "fake-lag", "Delays outgoing movement packets to simulate a lag spike.");
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (mc.player == null || mc.getConnection() == null) return;
        if (event.packet instanceof ServerboundMovePlayerPacket) {
            if (queue.size() >= maxQueued.get()) {
                // Flush one old packet rather than growing without bound.
                QueuedPacket old = queue.poll();
                if (old != null) old.connection.send(old.packet, null, true);
            }

            event.setCancelled(true);
            queue.add(new QueuedPacket(
                event.packet,
                event.connection,
                System.nanoTime() + delay.get() * 1_000_000L
            ));
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        long now = System.nanoTime();
        while (true) {
            QueuedPacket next = queue.peek();
            if (next == null || next.sendAtNanos > now) break;
            queue.poll();
            if (next.connection != null) {
                next.connection.send(next.packet, null, true);
            }
        }
    }

    @Override
    public void onDeactivate() {
        // Never leave queued movement packets stranded when toggled off.
        QueuedPacket packet;
        while ((packet = queue.poll()) != null) {
            if (packet.connection != null) {
                packet.connection.send(packet.packet, null, true);
            }
        }
    }

    private record QueuedPacket(Packet<?> packet, Connection connection, long sendAtNanos) {}
}
