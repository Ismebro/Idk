package com.mcberdasi.addon;

import com.mcberdasi.addon.modules.FakeLag;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class McberdasiAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("McberdasiAddon");
    public static final Category CATEGORY = new Category("Mcberdasi");

    @Override
    public void onInitialize() {
        LOG.info("Initializing Mcberdasi Addon");
        Modules.get().add(new FakeLag());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.mcberdasi.addon";
    }
}
